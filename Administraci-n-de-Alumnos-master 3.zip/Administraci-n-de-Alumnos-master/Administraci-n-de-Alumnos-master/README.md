# Administraci-n-de-Alumnos
Interfaz gráfica en Java que muestra una tabla con los registros de los alumnos, se agrega, edita y elimina alumnos. La información se guarda en un archivo txt.
Universidad Veracruzana | XalapaVeracruz
Trabajo de clase de pricipios de construcción.
