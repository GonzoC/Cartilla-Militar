package RegistroAlumnos;

import com.google.gson.Gson;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class AlumnosDAO {

    public static List<Alumno> getAlumnos(){
        Gson gson = new Gson();
        List<Alumno> lista = new ArrayList<Alumno>();
        try{
            List<String> datos = ArchivoUtils.leerArchivoTodo("Alumnos");
            for(String linea : datos){
                if(linea != null && !linea.isEmpty()){
                    lista.add(gson.fromJson(linea, Alumno.class));
                }
            }
        }catch(IOException e){
            e.printStackTrace();
        }
        return lista;
    }
    

    public static boolean guardarAlumno(Alumno a){
        Gson gson = new Gson();
        String linea = gson.toJson(a);
        try{
            ArchivoUtils.escribirEnArchivo("Alumnos", true, linea);
            return true;
        }catch(IOException ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public static void actualizarAdministrativo(List<Alumno> alumno, int indice, Alumno a){
        Gson gson = new Gson();
        ArchivoUtils.limpiarArchivo("Alumnos");
        int i=0;
        String linea = "";
        for(Alumno ad : alumno){
            if(indice == i){
                linea = gson.toJson(a);
            }else{
                linea = gson.toJson(ad);
            }
            try{
                ArchivoUtils.escribirEnArchivo("Alumnos", true, linea);
            }catch(IOException ex){
                ex.printStackTrace();
            }
            i++;
        } 
    }
    
    public static void eliminarAlumno(List<Alumno> alumnos, int indice){
        Gson gson = new Gson();
        int i = 0;
        ArchivoUtils.limpiarArchivo("Alumnos");
        String linea = "";
        for(Alumno ad : alumnos){
            if(indice != i){
                linea = gson.toJson(ad);
                try{
                ArchivoUtils.escribirEnArchivo("Alumnos", true, linea);
                }catch(IOException ex){
                ex.printStackTrace();
                }
            }
            
            i++;
        }
    }
}
