package RegistroAlumnos;

public class Alumno {
    private String nombre;
    private String AN;
    private String NE;
    private String M;
    private String P;
    private String EC;
    private String O;
    private String GDE;
    private String D;
    private String Curp;
    private String Zona;
    private String Matricula;
    
    Alumno(){
        
    }
    Alumno(String nombre,String nacimiento, String nacido, String madre,String padre, String estado, String ocupacion,String estudios, String domicilio, String curp, String zona, String matricula ){
        this.nombre = nombre;
        this.AN = nacimiento;
        this.NE = nacido;
        this.M = madre;
        this.P = padre;
        this.EC = estado;
        this.O = ocupacion;
        this.GDE = estudios;
        this.D = domicilio;
        this.Curp = curp;
        this.Zona = zona;
        this.Matricula = matricula;
        
    }

    public String getZona() {
        return Zona;
    }

    public void setZona(String Zona) {
        this.Zona = Zona;
    }

    public String getMatricula() {
        return Matricula;
    }

    public void setMatricula(String Matricula) {
        this.Matricula = Matricula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAN() {
        return AN;
    }

    public void setAN(String AN) {
        this.AN = AN;
    }

    public String getNE() {
        return NE;
    }

    public void setNE(String NE) {
        this.NE = NE;
    }

    public String getM() {
        return M;
    }

    public void setM(String M) {
        this.M = M;
    }

    public String getP() {
        return P;
    }

    public void setP(String P) {
        this.P = P;
    }

    public String getEC() {
        return EC;
    }

    public void setEC(String EC) {
        this.EC = EC;
    }

    public String getO() {
        return O;
    }

    public void setO(String O) {
        this.O = O;
    }

    public String getGDE() {
        return GDE;
    }

    public void setGDE(String GDE) {
        this.GDE = GDE;
    }

    public String getD() {
        return D;
    }

    public void setD(String D) {
        this.D = D;
    }

    public String getCurp() {
        return Curp;
    }

    public void setCurp(String Curp) {
        this.Curp = Curp;
    }
    
    
    
}
