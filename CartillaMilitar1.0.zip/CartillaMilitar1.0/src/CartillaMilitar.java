/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Anayansi
 */
public class CartillaMilitar {
    private String Nombre;
    private String Apellido;
    private String Añodenacimiento;
    private String RemisoE;

    public CartillaMilitar() {
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Añodenacimiento = Añodenacimiento;
        this.RemisoE = RemisoE;
    }

    CartillaMilitar(String Nombre, String Apellido, String Añodenacimiento, String RemisoE) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public String getAñodenacimiento() {
        return Añodenacimiento;
    }

    public void setAñodenacimiento(String Añodenacimiento) {
        this.Añodenacimiento = Añodenacimiento;
    }

    public String getRemisoE() {
        return RemisoE;
    }

    public void setRemisoE(String RemisoE) {
        this.RemisoE = RemisoE;
    }
    
    
    
}
