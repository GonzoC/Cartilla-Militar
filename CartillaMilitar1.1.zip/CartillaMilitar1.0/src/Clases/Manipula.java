package Clases;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
//import CartillaMilitar.<default package>.RegistroCartilla;
/**
 *
 * @author Anayansi
 */
public class Manipula {
 /**
    public static ArrayList < > cargaCasas(ArrayList <Object> reg)
    {
        try
        {
            ArrayList< > c = new ArrayList<>();
            for (int i = 0; i < reg.size(); i+=7)
            //Eliminar y sustituir por los datos de la tabla, datos tipo String´porque son letras 
            //Solo un dato tipo int por el ID
            {
                    String s= (String)reg.get(i);
                    if(s != "" && s != " ")
                    {    
                        String color = s;
                        double area = Double.parseDouble(((String) reg.get(i+1)).trim());
                        int noHabitaciones = Integer.parseInt(((String) reg.get(i+2)).trim());
                        int noPisos = Integer.parseInt(((String) reg.get(i+3)).trim());
                        int noVentanas = Integer.parseInt(((String) reg.get(i+4)).trim());
                        int noPuertas = Integer.parseInt(((String) reg.get(i+5)).trim());
                        int numero = Integer.parseInt(((String) reg.get(i+6)).trim());
                        Casa obj = new Casa(color, area, noHabitaciones, noPisos,
                                            noVentanas, noPuertas, numero);
                        c.add(obj);
                    }
            }
            return c;
        }catch(Exception e)
        {
                System.out.println(e.getMessage());
                return null;
        }
                
    }
    
    
   
    
    public static String consultaCasa(ArrayList <Casa> obj)
    {
        if(obj != null)
        {
            String s="";
            for (int i = 0; i < obj.size(); i++)
            {
                s+=obj.get(i).desp();
            }
            return s;
        }else
        {
            return "no hay datos encontrados";
        }
    }
    
    
    
    public static Connection Conectar()
    { 
        Conectar x = new Conectar();
        try
        {
            return x.Conecta("localhost:3306", "casas", "root", "123456", 2);
        } catch (SQLException ex)
        {
            return null;
        }   
    }
    
    public static void desconectaDB(Connection con)
    {
        Conectar x= new Conectar();
        x.desconectar(con);
    }
    
    public static ArrayList <Casa> consulta(Connection con,  String tabla, String id, String s)
    {
            
            ArrayList<Casa> lig= cargaCasas(consult(con,tabla,id,s));
            return lig;
    }
    
    
    public static ArrayList <Object> consult(Connection con,  String tabla, String id, String s)
    {
            int x=0;
            Querys sql = new Querys();
            ArrayList<Object> cad;
            try
            {
                x= Integer.parseInt(s);
                cad =  sql.Seleccion(con, "*", tabla, id+ "=" + String.valueOf(x));
            }catch(Exception e)
            {
                 cad =  sql.Seleccion(con, "*", tabla, "");
            }
            return cad;
    } 
    **/
}
