/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CartillaMilitar;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Anayansi
 */
public class CartillaMilitarDAO {
    public static List<CartillaMilitar> getCartilla(){
        Gson gson = new Gson();
        List<CartillaMilitar> lista = new ArrayList<CartillaMilitar>();
        try{
            List<String> datos = ArchivoU.leerArchivoTodo("CartillaMilitar");
            for(String linea : datos){
                if(linea != null && !linea.isEmpty()){
                    lista.add(gson.fromJson(linea, CartillaMilitar.class));
                }
            }
        }catch(IOException e){
            e.printStackTrace();
        }
        return lista;
    }
    
    public static boolean guardarCartilla(CartillaMilitar a){
        Gson gson = new Gson();
        String linea = gson.toJson(a);
        try{
            ArchivoU.escribirEnArchivo("CartillaMilitar", true, linea);
            return true;
        }catch(IOException ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public static void actualizarCartilla(List<CartillaMilitar> cartilla, int indice, CartillaMilitar a){
        Gson gson = new Gson();
        ArchivoU.limpiarArchivo("CartillaMilitar");
        int i=0;
        String linea = "";
        for(CartillaMilitar ad : cartilla){
            if(indice == i){
                linea = gson.toJson(a);
            }else{
                linea = gson.toJson(ad);
            }
            try{
                ArchivoU.escribirEnArchivo("CartillaMilitar", true, linea);
            }catch(IOException ex){
                ex.printStackTrace();
            }
            i++;
        } 
    }
 
    public static void eliminarAlumno(List<CartillaMilitar> cartillas, int indice){
        Gson gson = new Gson();
        int i = 0;
        ArchivoU.limpiarArchivo("CartillaMilitar");
        String linea = "";
        for(CartillaMilitar ad : cartillas){
            if(indice != i){
                linea = gson.toJson(ad);
                try{
                ArchivoU.escribirEnArchivo("CartillaMilitar", true, linea);
                }catch(IOException ex){
                ex.printStackTrace();
                }
            }
            
            i++;
        }
    }
}
