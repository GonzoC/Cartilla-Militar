/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CartillaMilitar;
import java.util.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 *
 * @author Anayansi
 */
public class ArchivoU {
    public static void escribirEnArchivo(String nombreArchivo, 
            boolean agregarfinal, String contenido) throws IOException{
        File archivo = new File(nombreArchivo+".txt");
        FileWriter w = new FileWriter(archivo, agregarfinal);
        BufferedWriter bw = new BufferedWriter(w);
        PrintWriter wr = new PrintWriter(bw);
        wr.append(contenido+"\n");
        wr.close();
        bw.close();
    }
    
    public static String leerArchivoLinea(String nombreArchivo, 
            int numlinea) throws FileNotFoundException, IOException{
        String resultado = null;
        File archivo = new File(nombreArchivo+".txt");
        boolean existe = archivo.exists();
        if(existe){
            String linea = "";
            FileReader f = new FileReader(archivo);
            BufferedReader b = new BufferedReader(f);
            int num = 1;
            while((linea = b.readLine())!= null){
                if(num == numlinea){
                    resultado = linea;
                    break;
                }
                num++;
            }
            b.close();
        }
        return resultado;
    }
    
    public static List<String> leerArchivoTodo(String nombreArchivo) 
            throws FileNotFoundException, IOException{
        List<String> contenido = new ArrayList<String>();
        File archivo = new File(nombreArchivo+".txt");
        boolean existe = archivo.exists();
        if(existe){
            String linea = "";
            FileReader f = new FileReader(archivo);
            BufferedReader b = new BufferedReader(f);
            while((linea = b.readLine())!= null){
                contenido.add(linea);
            }
            b.close();
        }
        return contenido;
    }
    public static void limpiarArchivo(String nombreArchivo){
        File archivo = new File(nombreArchivo+".txt");
        boolean existe = archivo.exists();
        if(existe){
            archivo.delete();
        }
    }
}
