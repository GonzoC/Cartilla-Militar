/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CartillaMilitar;

/**
 *
 * @author Anayansi
 */
public class CartillaMilitar {

 
   private String Nombre;
   private String ANacimiento;
   private String id;
   private String Nacido;
   private String Mamá;
   private String Padre;
   private String EstadoC;
   private String Ocupa;
   private String GradoE;
   private String Zona;
   private String Dirección;
   private String Matricula;
   private String Curp;


    public CartillaMilitar(String Nombre, String ANacimiento, String id, String Nacido, String Mamá, String Padre, String EstadoC, String Ocupa, String GradoE, String Zona, String Dirección, String Matricula, String Curp) {
        this.Nombre = Nombre;
        this.ANacimiento = ANacimiento;
        this.id=id;
        this.Nacido=Nacido;
        this.Mamá= Mamá;
        this.Padre = Padre;
        this.EstadoC = EstadoC;
        this.Ocupa=Ocupa;
        this.GradoE = GradoE;
        this.Zona = Zona;
        this.Dirección=Dirección;
        this.Matricula = Matricula;
        this.Curp = Curp;
    }

    public CartillaMilitar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public CartillaMilitar(String Nom, String ANac, String id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getANacimiento() {
        return ANacimiento;
    }

    public void setANacimiento(String ANacimiento) {
        this.ANacimiento = ANacimiento;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNacido() {
        return Nacido;
    }

    public void setNacido(String Nacido) {
        this.Nacido = Nacido;
    }

    public String getMamá() {
        return Mamá;
    }

    public void setMamá(String Mamá) {
        this.Mamá = Mamá;
    }

    public String getPadre() {
        return Padre;
    }

    public void setPadre(String Padre) {
        this.Padre = Padre;
    }

    public String getEstadoC() {
        return EstadoC;
    }

    public void setEstadoC(String EstadoC) {
        this.EstadoC = EstadoC;
    }

    public String getOcupa() {
        return Ocupa;
    }

    public void setOcupa(String Ocupa) {
        this.Ocupa = Ocupa;
    }

    public String getGradoE() {
        return GradoE;
    }

    public void setGradoE(String GradoE) {
        this.GradoE = GradoE;
    }

    public String getZona() {
        return Zona;
    }

    public void setZona(String Zona) {
        this.Zona = Zona;
    }

    public String getDirección() {
        return Dirección;
    }

    public void setDirección(String Dirección) {
        this.Dirección = Dirección;
    }

    public String getMatricula() {
        return Matricula;
    }

    public void setMatricula(String Matricula) {
        this.Matricula = Matricula;
    }

    public String getCurp() {
        return Curp;
    }

    public void setCurp(String Curp) {
        this.Curp = Curp;
    }
}
